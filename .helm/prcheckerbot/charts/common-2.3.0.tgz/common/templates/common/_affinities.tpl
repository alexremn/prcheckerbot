{{/*
=============================================================================
AFFINITY TEMPLATES
This file contains templates for Kubernetes pod and node affinities.

Usage examples:
Node affinity: {{ include "common.affinities.nodes" (dict "type" "soft" "key" "node-role" "values" (list "worker")) }}
Pod affinity: {{ include "common.affinities.pods" (dict "type" "soft" "component" "web" "context" $) }}
Pod anti-affinity: {{ include "common.affinities.podAntiAffinity" (dict "component" "web" "context" $) }}
=============================================================================
*/}}

{{/*
Default topologyKey with intelligent fallback mechanism
Usage: {{ include "common.affinities.topologyKey" (dict "topologyKey" "topology.kubernetes.io/zone") }}
*/}}
{{- define "common.affinities.topologyKey" -}}
{{- if .topologyKey -}}
  {{- .topologyKey -}}
{{- else -}}
  {{- "kubernetes.io/hostname" -}}
{{- end -}}
{{- end -}}

{{/*
=============================================================================
NODE AFFINITY TEMPLATES
=============================================================================
*/}}

{{/*
Soft (preferred) node affinity definition
Usage: {{ include "common.affinities.nodes.soft" (dict "key" "instance-type" "values" (list "c5.large" "c5.xlarge") "weight" 50) }}
*/}}
{{- define "common.affinities.nodes.soft" -}}
preferredDuringSchedulingIgnoredDuringExecution:
  - preference:
      matchExpressions:
        - key: {{ .key }}
          operator: In
          values:
            {{- range .values }}
            - {{ . | quote }}
            {{- end }}
    weight: {{ default 1 .weight }}
{{- end -}}

{{/*
Hard (required) node affinity definition
Usage: {{ include "common.affinities.nodes.hard" (dict "key" "instance-type" "values" (list "c5.large" "c5.xlarge")) }}
*/}}
{{- define "common.affinities.nodes.hard" -}}
requiredDuringSchedulingIgnoredDuringExecution:
  nodeSelectorTerms:
    - matchExpressions:
        - key: {{ .key }}
          operator: In
          values:
            {{- range .values }}
            - {{ . | quote }}
            {{- end }}
{{- end -}}

{{/*
General node affinity definition with specified type (soft or hard)
Usage: {{ include "common.affinities.nodes" (dict "type" "soft" "key" "instance-type" "values" (list "c5.large" "c5.xlarge") "weight" 50) }}
*/}}
{{- define "common.affinities.nodes" -}}
  {{- if eq .type "soft" }}
    {{- include "common.affinities.nodes.soft" . -}}
  {{- else if eq .type "hard" }}
    {{- include "common.affinities.nodes.hard" . -}}
  {{- else }}
    {{- fail (printf "Unknown affinity type: %s. Must be 'soft' or 'hard'" .type) -}}
  {{- end -}}
{{- end -}}

{{/*
=============================================================================
POD AFFINITY TEMPLATES
=============================================================================
*/}}

{{/*
Soft (preferred) pod affinity/anti-affinity definition
Usage: {{ include "common.affinities.pods.soft" (dict "component" "web" "extraMatchLabels" .Values.extraMatchLabels "topologyKey" "topology.kubernetes.io/zone" "context" $) }}
*/}}
{{- define "common.affinities.pods.soft" -}}
{{- $component := default "" .component -}}
{{- $extraMatchLabels := default (dict) .extraMatchLabels -}}
{{- $weight := default 1 .weight | int -}}
preferredDuringSchedulingIgnoredDuringExecution:
  - podAffinityTerm:
      labelSelector:
        matchLabels: {{- (include "common.labels.matchLabels" .context) | nindent 10 }}
          {{- if not (empty $component) }}
          app.kubernetes.io/component: {{ $component }}
          {{- end }}
          {{- range $key, $value := $extraMatchLabels }}
          {{ $key }}: {{ $value | quote }}
          {{- end }}
      topologyKey: {{ include "common.affinities.topologyKey" (dict "topologyKey" .topologyKey) }}
    weight: {{ $weight }}
{{- end -}}

{{/*
Hard (required) pod affinity/anti-affinity definition
Usage: {{ include "common.affinities.pods.hard" (dict "component" "web" "extraMatchLabels" .Values.extraMatchLabels "topologyKey" "topology.kubernetes.io/zone" "context" $) }}
*/}}
{{- define "common.affinities.pods.hard" -}}
{{- $component := default "" .component -}}
{{- $extraMatchLabels := default (dict) .extraMatchLabels -}}
requiredDuringSchedulingIgnoredDuringExecution:
  - labelSelector:
      matchLabels: {{- (include "common.labels.matchLabels" .context) | nindent 8 }}
        {{- if not (empty $component) }}
        app.kubernetes.io/component: {{ $component }}
        {{- end }}
        {{- range $key, $value := $extraMatchLabels }}
        {{ $key }}: {{ $value | quote }}
        {{- end }}
    topologyKey: {{ include "common.affinities.topologyKey" (dict "topologyKey" .topologyKey) }}
{{- end -}}

{{/*
General pod affinity/anti-affinity definition with specified type (soft or hard)
Usage: {{ include "common.affinities.pods" (dict "type" "soft" "component" "web" "extraMatchLabels" .Values.extraMatchLabels "topologyKey" "topology.kubernetes.io/zone" "context" $) }}
*/}}
{{- define "common.affinities.pods" -}}
  {{- if eq .type "soft" }}
    {{- include "common.affinities.pods.soft" . -}}
  {{- else if eq .type "hard" }}
    {{- include "common.affinities.pods.hard" . -}}
  {{- else }}
    {{- fail (printf "Unknown affinity type: %s. Must be 'soft' or 'hard'" .type) -}}
  {{- end -}}
{{- end -}}

{{/*
Complete pod anti-affinity configuration with multi-zone and multi-node distribution
Provides a balanced distribution of pods across zones (high weight) and nodes (medium weight)
Usage: {{ include "common.affinities.podAntiAffinity" (dict "component" "web" "context" $) }}
*/}}
{{- define "common.affinities.podAntiAffinity" -}}
podAntiAffinity:
  {{- include "common.affinities.pods.soft" (dict
    "component" .component
    "weight" 100
    "topologyKey" "topology.kubernetes.io/zone"
    "context" .context) | nindent 2 }}
  {{- include "common.affinities.pods.soft" (dict
    "component" .component
    "weight" 50
    "topologyKey" "kubernetes.io/hostname"
    "context" .context) | nindent 2 }}
{{- end -}}

{{/*
Combined affinity helper for complete affinity configuration
Usage: {{ include "common.affinities.complete" (dict "component" "web" "nodeAffinityType" "soft" "nodeKey" "node-role" "nodeValues" (list "worker") "context" $) }}
*/}}
{{- define "common.affinities.complete" -}}
{{- $nodeAffinityType := default "soft" .nodeAffinityType -}}
{{- $nodeKey := default "" .nodeKey -}}
{{- $nodeValues := default (list) .nodeValues -}}
affinity:
  {{- if and $nodeKey $nodeValues }}
  nodeAffinity:
    {{- include "common.affinities.nodes" (dict "type" $nodeAffinityType "key" $nodeKey "values" $nodeValues) | nindent 4 }}
  {{- end }}

  {{- include "common.affinities.podAntiAffinity" (dict "component" .component "context" .context) | nindent 2 }}
{{- end -}}

{{/*
Legacy slice-form nodeAffinity emitter (relocated from _pod.tpl).
Each entry: key, operator (default "In"), value (single string).
Values are quoted so numeric zone ids stay []string (fixes P1-6).
Map-form nodeAffinity is passed through by the caller via toYaml.
*/}}
{{- define "common.affinities.legacy.nodeSlice" -}}
nodeAffinity:
  requiredDuringSchedulingIgnoredDuringExecution:
    nodeSelectorTerms:
    {{- range . }}
      - matchExpressions:
          - key: {{ .key }}
            operator: {{ default "In" .operator }}
            values:
              - {{ .value | quote }}
    {{- end }}
{{- end -}}

{{/*
Legacy default/custom podAntiAffinity emitter (relocated from _pod.tpl,
output byte-identical). `.val.default` emits the 100/99 zone+host spread;
`.val.custom` is appended verbatim.
*/}}
{{- define "common.affinities.legacy.podAntiAffinity" }}
podAntiAffinity:
{{- if .val.default }}
  preferredDuringSchedulingIgnoredDuringExecution:
  - weight: 100
    podAffinityTerm:
      labelSelector:
        matchExpressions:
        - key: app.kubernetes.io/name
          operator: In
          values:
          - {{ .svc }}
        - key: app.kubernetes.io/component
          operator: In
          values:
          - {{ .cmp }}
        - key: helm.sh/environment
          operator: In
          values:
          - {{ .env }}
      topologyKey: topology.kubernetes.io/zone
  - weight: 99
    podAffinityTerm:
      labelSelector:
        matchExpressions:
        - key: app.kubernetes.io/name
          operator: In
          values:
          - {{ .svc }}
        - key: app.kubernetes.io/component
          operator: In
          values:
          - {{ .cmp }}
        - key: helm.sh/environment
          operator: In
          values:
          - {{ .env }}
      topologyKey: kubernetes.io/hostname
{{- end }}
{{ with .val.custom }}
  {{ toYaml . | nindent 2 }}
{{- end }}
{{- end }}
